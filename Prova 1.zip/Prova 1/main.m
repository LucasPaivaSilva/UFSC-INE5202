# Lucas Paiva da Silva (20100417)
# INE5202
'-> Prova 1 <-'
'-> Lucas Paiva da Silva <-'
''
'-> Questão 2 <-'
q2 # Chama e executa o arquivo com a questão 2
'-> Questão 3 <-'
q3 # Chama e executa o arquivo com a "questão 3" -> 2i, 2ii e 2iii no moodle